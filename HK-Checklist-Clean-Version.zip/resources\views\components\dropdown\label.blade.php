<div class="px-3 py-1 text-xs uppercase tracking-wide text-gray-400 dark:text-gray-500">
    {{ $slot }}
</div>
