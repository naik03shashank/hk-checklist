<div
    {{ $attributes->merge(['class' => 'overflow-hidden rounded p-4 sm:p-8 bg-white shadow text-gray-600 dark:text-gray-400 sm:rounded-lg dark:bg-gray-800 max-w-full']) }}>
    {{ $slot }}
</div>
