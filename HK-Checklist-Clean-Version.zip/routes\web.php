<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PropertyController;
use App\Http\Controllers\ChecklistController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\ManageSessionController;
use App\Http\Controllers\TeamController;
use App\Models\User;
use App\Models\CleaningSession;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', DashboardController::class)->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Properties
    Route::resource('properties', PropertyController::class);
    
    // Rooms within properties
    Route::get('properties/{property}/rooms', [PropertyController::class, 'rooms'])->name('properties.rooms.index');
    Route::put('properties/{property}/rooms/{room}', [PropertyController::class, 'updateRoom'])->name('properties.rooms.update');
    Route::delete('properties/{property}/rooms/{room}', [PropertyController::class, 'destroyRoom'])->name('properties.rooms.destroy');
    
    // Tasks within rooms
    Route::get('properties/{property}/rooms/{room}/tasks', [PropertyController::class, 'tasks'])->name('properties.tasks.index');
    Route::post('properties/{property}/rooms/{room}/tasks', [PropertyController::class, 'storeTask'])->name('properties.tasks.store');
    Route::post('properties/{property}/rooms/{room}/tasks/bulk', [PropertyController::class, 'bulkStoreTask'])->name('properties.tasks.bulk-store');
    Route::put('properties/{property}/rooms/{room}/tasks/{task}', [PropertyController::class, 'updateTask'])->name('properties.tasks.update');
    Route::delete('properties/{property}/rooms/{room}/tasks/{task}', [PropertyController::class, 'detachTask'])->name('properties.tasks.detach');
    
    // Property-level tasks
    Route::get('properties/{property}/tasks', [PropertyController::class, 'propertyTasks'])->name('properties.property-tasks.index');
    Route::post('properties/{property}/tasks', [PropertyController::class, 'storePropertyTask'])->name('properties.property-tasks.store');
    Route::put('properties/{property}/tasks/{task}', [PropertyController::class, 'updatePropertyTask'])->name('properties.property-tasks.update');
    Route::delete('properties/{property}/tasks/{task}', [PropertyController::class, 'detachPropertyTask'])->name('properties.property-tasks.detach');

    // Housekeeper Sessions
    Route::get('/sessions', [SessionController::class, 'index'])->name('sessions.index');
    Route::get('/sessions/{session}', [SessionController::class, 'show'])->name('sessions.show');
    Route::post('/sessions/{session}/start', [SessionController::class, 'start'])->name('sessions.start');
    Route::post('/sessions/{session}/complete', [SessionController::class, 'complete'])->name('sessions.complete');
    
    // API for Checklist Interactions
    Route::get('/api/sessions/{session}/data', [SessionController::class, 'getData'])->name('sessions.data');
    Route::post('/sessions/{session}/rooms/{room}/tasks/{task}/toggle', [ChecklistController::class, 'toggle'])->name('checklist.toggle');
    Route::post('/sessions/{session}/rooms/{room}/tasks/{task}/note', [ChecklistController::class, 'note'])->name('checklist.note');
    Route::post('/sessions/{session}/rooms/{room}/tasks/{task}/photo', [ChecklistController::class, 'taskPhoto'])->name('checklist.photo');
    Route::delete('/sessions/{session}/rooms/{room}/tasks/{task}/photo/{photo}', [ChecklistController::class, 'deletePhoto'])->name('checklist.photo.delete');

    // Property-level checklist interactions (no room)
    Route::post('/sessions/{session}/tasks/{task}/toggle', [ChecklistController::class, 'togglePropertyTask'])->name('checklist.property-task.toggle');
    Route::post('/sessions/{session}/tasks/{task}/note', [ChecklistController::class, 'notePropertyTask'])->name('checklist.property-task.note');
    Route::post('/sessions/{session}/tasks/{task}/photo', [ChecklistController::class, 'propertyTaskPhoto'])->name('checklist.property-task.photo');

    // Add Session Routes (Admin/Owner)
    Route::get('/manage/sessions', [ManageSessionController::class, 'index'])->name('manage.sessions.index');
    Route::get('/manage/sessions/create', [ManageSessionController::class, 'create'])->name('manage.sessions.create');
    Route::post('/manage/sessions', [ManageSessionController::class, 'store'])->name('manage.sessions.store');
    Route::get('/manage/sessions/{session}/edit', [ManageSessionController::class, 'edit'])->name('manage.sessions.edit');
    Route::put('/manage/sessions/{session}', [ManageSessionController::class, 'update'])->name('manage.sessions.update');
    Route::delete('/manage/sessions/{session}', [ManageSessionController::class, 'destroy'])->name('manage.sessions.destroy');

    // Calendar Routes
    Route::get('/calendar', [CalendarController::class, 'index'])->name('calendar.index');
    Route::get('/api/calendar/events', [CalendarController::class, 'events'])->name('api.calendar.events');

    // Team Routes
    Route::get('/team', [TeamController::class, 'index'])->name('team.index');
    Route::get('/team/create', [TeamController::class, 'create'])->name('team.create');
    Route::post('/team', [TeamController::class, 'store'])->name('team.store');
    Route::get('/team/{user}/edit', [TeamController::class, 'edit'])->name('team.edit');
    Route::put('/team/{user}', [TeamController::class, 'update'])->name('team.update');
    Route::delete('/team/{user}', [TeamController::class, 'destroy'])->name('team.destroy');
});




require __DIR__.'/auth.php';
