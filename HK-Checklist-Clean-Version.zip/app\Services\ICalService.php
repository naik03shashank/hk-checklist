<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;

use Illuminate\Support\Facades\Cache;

class ICalService
{
    /**
     * Fetch and parse iCal events from a URL.
     * Returns an array of events: [['uid' => ..., 'summary' => ..., 'dtstart' => ..., 'dtend' => ...], ...]
     */
    public function fetchEvents(string $url, $cacheKey = null, string $source = null): array
    {
        $key = $cacheKey ? "ical_events_{$cacheKey}" : 'ical_events_' . md5($url);

        return Cache::remember($key, 3600, function () use ($url, $source) { // Cache for 1 hour
            try {
                // Fetch content with a timeout
                $response = Http::timeout(10)->get($url);

                if ($response->failed()) {
                    Log::warning("Failed to fetch iCal from URL: {$url}. Status: " . $response->status());
                    return [];
                }

                $content = $response->body();
                return $this->parseICS($content, $source);

            } catch (\Exception $e) {
                Log::error("Exception fetching iCal from {$url}: " . $e->getMessage());
                return [];
            }
        });
    }

    /**
     * Parse raw ICS content into a structured array.
     */
    private function parseICS(string $content, string $source = null): array
    {
        $events = [];
        
        // Normalize line endings
        $content = str_replace("\r\n", "\n", $content);
        $lines = explode("\n", $content);

        $currentEvent = [];
        $inEvent = false;

        foreach ($lines as $line) {
            $line = trim($line);
            
            if ($line === 'BEGIN:VEVENT') {
                $inEvent = true;
                $currentEvent = [];
                continue;
            }

            if ($line === 'END:VEVENT') {
                $inEvent = false;
                if (!empty($currentEvent['dtstart']) && !empty($currentEvent['dtend'])) {
                    $events[] = $currentEvent;
                }
                continue;
            }

            if ($inEvent) {
                if (str_starts_with($line, 'UID:')) {
                    $currentEvent['uid'] = substr($line, 4);
                } elseif (str_starts_with($line, 'SUMMARY:')) {
                    $currentEvent['summary'] = substr($line, 8);
                } elseif (str_starts_with($line, 'DTSTART;VALUE=DATE:')) {
                    $currentEvent['dtstart'] = substr($line, 19);
                    $currentEvent['is_all_day'] = true;
                } elseif (str_starts_with($line, 'DTSTART:')) {
                    $currentEvent['dtstart'] = substr($line, 8);
                    $currentEvent['is_all_day'] = false;
                } elseif (str_starts_with($line, 'DTEND;VALUE=DATE:')) {
                    $currentEvent['dtend'] = substr($line, 17);
                } elseif (str_starts_with($line, 'DTEND:')) {
                    $currentEvent['dtend'] = substr($line, 6);
                }
            }
        }

        return $this->processEvents($events, $source);
    }

    /**
     * Post-process events: parse dates, sort, filter.
     */
    private function processEvents(array $rawEvents, string $source = null): array
    {
        $processed = [];
        $now = Carbon::today()->subDays(30); // Look back 30 days max for relevance
        $future = Carbon::today()->addYear();

        foreach ($rawEvents as $event) {
            try {
                // Parse dates
                $start = $this->parseDate($event['dtstart']);
                $end = $this->parseDate($event['dtend']);

                if (!$start || !$end) continue;

                // Adjust for checkout date logic:
                // Airbnb/Vrbo usually send check-out day as DTEND. 
                
                // Filter out obviously old or too far future
                if ($end->lt($now) || $end->gt($future)) continue;

                $processed[] = [
                    'uid' => $event['uid'] ?? uniqid(),
                    'summary' => $event['summary'] ?? 'Booking',
                    'start_date' => $start->toDateString(),
                    'end_date' => $end->toDateString(), // This is the checkout date
                    'source' => $source
                ];
            } catch (\Exception $e) {
                continue; // Skip malformed dates
            }
        }

        // Sort by date desc
        usort($processed, fn($a, $b) => strcmp($b['end_date'], $a['end_date']));

        return $processed;
    }

    private function parseDate($dateStr)
    {
        // Handle basic YYYYMMDD
        if (preg_match('/^\d{8}$/', $dateStr)) {
            return Carbon::createFromFormat('Ymd', $dateStr)->startOfDay();
        }
        // Handle YYYYMMDDTHHMMSSZ
        if (preg_match('/^\d{8}T\d{6}Z?$/', $dateStr)) {
            return Carbon::parse($dateStr);
        }
        return null;
    }
}
