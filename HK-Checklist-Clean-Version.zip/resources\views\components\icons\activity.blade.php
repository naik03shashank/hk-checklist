<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"
    class="h-5 w-5 text-gray-700 dark:text-gray-200" role="img" aria-label="Activity Log">
    <title>Activity Log</title>

    <!-- Lines -->
    <path stroke-linecap="round" d="M4 6h9M4 12h14M4 18h9" />

    <!-- Dots (events) -->
    <circle cx="18" cy="6" r="1.8" fill="currentColor" />
    <circle cx="12" cy="12" r="1.8" fill="currentColor" />
    <circle cx="18" cy="18" r="1.8" fill="currentColor" />
</svg>
